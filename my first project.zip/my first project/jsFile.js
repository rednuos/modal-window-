$(document).ready (function() {
  $('.toggleButton').click( function(){
  	$('.background-window').fadeIn(800);
    $('.modalWindow').fadeIn(800);
  });
  $('.cancelButton').click( function() {
   $('.background-window').hide();
   $('.modalWindow').hide();
  });
});